
class SignUpIncoming  {
    var serverData : [String: Any] = [:]
    var body : [Body]?
    var success : Int?
    var message : String?
    init(dict: [String: Any]){
        self.serverData = dict
        
        if let body = dict["body"] as? [[String : Any]] {
            self.body = []
            for object in body {
                let some =  Body(dict: object)
                self.body?.append(some)
                
            }
        }
        if let success = dict["success"] as? Int {
            self.success = success
        }
        if let message = dict["message"] as? String {
            self.message = message
        }
    }
    
    class Body  {
        var serverData : [String: Any] = [:]
        var utr : String?
        var auth : String?
        var title : String?
        var email : String?
        var status : Int?
        var gender : String?
        var user_id : Int?
        var country : String?
        var lastname : String?
        var password : String?
        var town_city : String?
        var address_2 : String?
        var telephone : Int?
        var address_1 : String?
        var ni_number : String?
        var post_code : Int?
        var income_ids : String?
        var created_at : String?
        var firstaname : String?
        var device_type : String?
        var device_token : String?
        var date_of_birth : String?
        var tax_relief_ids : String?
        var email_varification : String?
        init(dict: [String: Any]){
            self.serverData = dict
            
            if let utr = dict["utr"] as? String {
                self.utr = utr
            }
            if let auth = dict["auth"] as? String {
                self.auth = auth
            }
            if let title = dict["title"] as? String {
                self.title = title
            }
            if let email = dict["email"] as? String {
                self.email = email
            }
            if let status = dict["status"] as? Int {
                self.status = status
            }
            if let gender = dict["gender"] as? String {
                self.gender = gender
            }
            if let user_id = dict["user_id"] as? Int {
                self.user_id = user_id
            }
            if let country = dict["country"] as? String {
                self.country = country
            }
            if let lastname = dict["lastname"] as? String {
                self.lastname = lastname
            }
            if let password = dict["password"] as? String {
                self.password = password
            }
            if let town_city = dict["town_city"] as? String {
                self.town_city = town_city
            }
            if let address_2 = dict["address_2"] as? String {
                self.address_2 = address_2
            }
            if let telephone = dict["telephone"] as? Int {
                self.telephone = telephone
            }
            if let address_1 = dict["address_1"] as? String {
                self.address_1 = address_1
            }
            if let ni_number = dict["ni_number"] as? String {
                self.ni_number = ni_number
            }
            if let post_code = dict["post_code"] as? Int {
                self.post_code = post_code
            }
            if let income_ids = dict["income_ids"] as? String {
                self.income_ids = income_ids
            }
            if let created_at = dict["created_at"] as? String {
                self.created_at = created_at
            }
            if let firstaname = dict["firstaname"] as? String {
                self.firstaname = firstaname
            }
            if let device_type = dict["device_type"] as? String {
                self.device_type = device_type
            }
            if let device_token = dict["device_token"] as? String {
                self.device_token = device_token
            }
            if let date_of_birth = dict["date_of_birth"] as? String {
                self.date_of_birth = date_of_birth
            }
            if let tax_relief_ids = dict["tax_relief_ids"] as? String {
                self.tax_relief_ids = tax_relief_ids
            }
            if let email_varification = dict["email_varification"] as? String {
                self.email_varification = email_varification
            }
        }
    }
}
