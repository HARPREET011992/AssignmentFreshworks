//
//  CoreDataMethods.swift
//  FreshWorksAssignment
//
//  Created by Happy on 2021-08-08.
//

//import Foundation
//import UIKit
//import CoreData
//class CoreDataMethods:NSObject {
//    var context = CoreDataStack.sharedInstance.persistentContainer.viewContext
//    
//    func getAllItems() {
//        do {
//            let url = try context.fetch(GifData.fetchRequest())
//        }catch{
//            
//        }
//    }
//    func create(url:String) {
//        let newurl = GifData(context: context)
//        newurl.gifUrl = url
//        do {
//            try context.save()
//        }catch{
//            //error
//        }
//    }
//    
//}
