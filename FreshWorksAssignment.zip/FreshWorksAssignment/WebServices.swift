//

import Foundation
import Alamofire

//{
typealias CompletionBlock = ([String : Any]) -> Void
typealias FailureBlock = ([String : Any]) -> Void
typealias ProgressBlock = (Double) -> Void
typealias ComletionBlock1 = ([String: Any]) -> Void
typealias FailureBlock1  = ([String: Any]) -> Void
typealias ProgressBlock1 = (Double) -> Void
//}

func isConnectedToInternet() ->Bool {
    return NetworkReachabilityManager()!.isReachable
}

extension String: ParameterEncoding {
    public func encode(_ urlRequest: URLRequestConvertible, with parameters: Parameters?) throws -> URLRequest {
        var request = try urlRequest.asURLRequest()
        request.httpBody = data(using: .utf8, allowLossyConversion: false)
        return request
    }

}

extension Data: ParameterEncoding {
    public func encode(_ urlRequest: URLRequestConvertible, with parameters: Parameters?) throws -> URLRequest {
        var request = try urlRequest.asURLRequest()
        request.httpBody = self
        return request
    }
    
}



//class WebServices {
    
class WebServices{
    
    enum Contenttype: String {
        case applicationJson = "application/json"
     //   case forHTTPHeaderField = "Content-type"
        case textPlain = "text/plain"
        
    }
  
    
    
    class func postWithHeader(url : String,jsonObject: [String : Any]  ,
                     method : HTTPMethod? = .post,
                     header: HTTPHeaders? = nil,
                     completionHandler: CompletionBlock? = nil,
                     failureHandler: FailureBlock? = nil ) {
        
        let urlString = url
        
        print(urlString)
        
        let parameters: Parameters = jsonObject
        
        Alamofire.request(urlString, method: method!, parameters: parameters, headers: header).responseJSON { (response) in
            switch (response.result) {
                
            case .success(let value):
                completionHandler!(value as! [String: Any])
                
            case .failure(let error):
                print(error)
                failureHandler?([:])
                
            }
            }.responseString { _ in
                
            }.responseData { response  in
                if let data = response.result.value, let utf8Text = String(data: data, encoding: .utf8){
                    //print("Data: \(utf8Text)")
                }
        }
    }
    
    
    
    
}
