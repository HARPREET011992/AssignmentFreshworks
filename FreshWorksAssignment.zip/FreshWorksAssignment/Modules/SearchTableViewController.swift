//
//  SearchTableViewController.swift
//  FreshWorksAssignment
//
//  Created by Happy on 2021-08-07.
//

import UIKit
import SwiftyGif
import Alamofire
import SwiftyJSON
class SearchTableViewController: UIViewController {
    let api = NetworkManager()
    var database = DatabaseHandler()
    @IBOutlet var searchTableView: UITableView!
    let searchController = UISearchController(searchResultsController: nil)
    var gifModel: JSON?
    var offsetCount = 0
    var totalCount = 0
    var dataModel = [GiphyData]()
    var gifStringArr = [String:Bool]()
    var favList : [GifData]? = []
    var checked = false
    var isloading = false
    var num = 0
    var giphyArray = [GiphyDataModel]()
    var gifData : JSON?
    var gifTrendingUrl: URL {
         return URL(string: "http://api.giphy.com/v1/gifs/trending")!
        
    }
    var gifSearchingUrl: URL {
         return URL(string: "http://api.giphy.com/v1/gifs/search")!
        
    }
    var selectedURL = [String]()
    var selectedGifModel : JSON?
    var timer = Timer.init()
    var searchText = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        updateTableContent()
        setupTableView()
        setupSearchBar()
      
        clearCoreData()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
       
    }
    
   
    func clearCoreData() {
        database.clearData(GifData.self)
    }
    override class func description() -> String {
        "SearchViewController"
    }
    func checkButton(sender:UIButton,i:Int) {
        let imageURL = gifModel?["data"][i]["images"]["downsized"]["url"].rawString()
                        if let favData = favList {
                            if favData.count > 0 {
                                for f in favData {
                                 if f.gifUrl == imageURL{
                                    sender.isSelected = true
                                 }else {
                                    print("this is not the url")
                                 }
                            }
        
                            }else {
                                sender.isSelected = false
                            }
                    }
    }
    func updateArrfromCoreData(selectedurl:String){
//        if JSON(rawValue: favList!) ?? <#default value#> >  JSON(rawValue: {
//        gifStringArr[favList![i].gifUrl] == true
       
    }
//    if let favData = favList {
//        for f in favData {
//            for url in selectedURL {
//
//            if f.isFav && f.gifUrl == url{
//           // let arr = selectedTaggedUser.filter({$0._id == studentDataList[indexPath.row]._id}) using this wayok
//                database.delete(object:(favList?.remove(at: sender.tag))!)
//                f.isFav = false
//                database.save()
//                guard let favMovies = database.add(GifData.self) else {
//                    return
//                    }

      


//     func scrollViewDidScroll(_ scrollView: UIScrollView) {
//            let offsetY = scrollView.contentOffset.y
//            let contentHeight = scrollView.contentSize.height
//
//            if (offsetY > contentHeight - scrollView.frame.height * 4) && !isloading {
//                offsetCount += 50
//                getGifDataFromServer()
//            }
//        }
    func getGifDataFromServer(){
      
        let parm = [URLQueryItem(name: "api_key", value: "Qvz4B1vkcNUr8V68lMgs5eX8HR7v2Hx1"),URLQueryItem(name: "offset", value:String(offsetCount))]
        api.getApiData(requestUrl:  gifTrendingUrl.absoluteString, parameters: parm, result: GiphyModel.self) { response   in
             self.gifModel = response
            DispatchQueue.main.async {
                self.searchTableView.reloadData()
            }
           
        }

}

}
extension SearchTableViewController : UISearchControllerDelegate,UISearchResultsUpdating  {
    func setupSearchBar() {
        searchController.searchResultsUpdater = self
        searchController.hidesNavigationBarDuringPresentation = false
        searchController.dimsBackgroundDuringPresentation = false
        searchController.searchBar.sizeToFit()
        self.searchTableView.tableHeaderView = searchController.searchBar
    }
    func updateSearchResults(for searchController: UISearchController) {
        
        timer.invalidate()
        guard let text = searchController.searchBar.text else { return }
        print(#line,#file)
        searchText = text
        
        timer = Timer.scheduledTimer(timeInterval: 0.5, target: self, selector: #selector(searchAPI), userInfo: nil, repeats: false)
    }
    
    @objc func searchAPI()
    {
        print(searchText)
        if(searchText == "")
        {
            self.getGifDataFromServer()
        }
        else{
        let parm = [URLQueryItem(name: "q", value: searchText), URLQueryItem(name: "api_key", value: "Qvz4B1vkcNUr8V68lMgs5eX8HR7v2Hx1")]
            
            api.getApiData(requestUrl: gifSearchingUrl.absoluteString, parameters: parm, result: GiphyModel.self) { res  in
                self.gifModel = res
                DispatchQueue.main.async {
                    self.searchTableView.reloadData()
                }
            }
                
            }
            }
        }
//if favList?.count ?? 0 > 0 {
 
//  self.updateArrfromCoreData()
//                self.gifData = self.gifModel?["data"]
//                if self.gifData?.count ?? 0 > 0 {
////                   self.giphyArray.removeAll()
//                    for i in 0 ..< self.gifData!.count{
//                        let imageURL = self.gifData?[i]["images"]["downsized"]["url"].rawString()
//                    let newitem = GiphyDataModel()
//                    newitem.giphyUrl = imageURL!
//                    newitem.fav = false
//                    self.giphyArray.append(newitem)


extension SearchTableViewController : UITableViewDelegate,UITableViewDataSource {
    func setupTableView() {
        searchTableView.delegate = self
        searchTableView.dataSource = self
    }
    func updateTableContent() {
        getGifDataFromServer()
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
       return 300
   }
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if totalCount > offsetCount {
            return gifModel?["data"].count  ?? 0 + 1
        }else {
            return gifModel?["data"].count ?? 0
        }
     
   }
   
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if let cell = tableView.dequeueReusableCell(withIdentifier: "GifSearchTableViewCell", for: indexPath) as? GifSearchTableViewCell
        {

            cell.setupCell()
            if let imageURL = gifModel?["data"][indexPath.row]["images"]["downsized"]["url"].rawString()
            {
                cell.setCellData(_data: imageURL)
                checkButton(sender:cell.gifFavButton, i: indexPath.row)
//                updateArrfromCoreData()
//                let newitem = GiphyDataModel()
//                newitem.giphyUrl = imageURL
//                newitem.fav = false
//                giphyArray.append(newitem)
//            }
            }
            cell.favButtonAction = {[unowned self] in
                if (cell.gifFavButton.isSelected){
                    cell.gifFavButton.isSelected = false
                    cell.gifFavButton.setImage(UIImage(systemName: "suit.heart"), for: .normal)
                    if let imageURL = gifModel?["data"][indexPath.row]["images"]["downsized"]["url"].rawString()
                    {
                        if let favData = favList {
                            for i in 0..<favData.count {
                                if favData[i].isFav && favData[i].gifUrl == imageURL{
                                    database.delete(object:((favList?.remove(at: i))!))
                                    favData[i].isFav = false
                                    database.save()
                                }else{
                                    print("its not fav")
                                }
                            }
                        }
                    }

                }

                else {
                    cell.gifFavButton.isSelected = true
                    cell.gifFavButton.setImage(UIImage(systemName: "heart.fill"), for: .normal)

                        if let imageURL = gifModel?["data"][indexPath.row]["images"]["downsized"]["url"].rawString()
                        {
                                guard let favMovies = database.add(GifData.self) else {
                                    return
                                }
                                favMovies.gifUrl = imageURL
                                favMovies.isFav = true
                                favList?.append(favMovies)
                                database.save()
//                            }
                            print(favList?.first?.isFav)

                        }


                }
            }
            return cell

        }
        else  { return UITableViewCell() }

    }
}
//testing extension
//extension SearchTableViewController {
//    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
//        guard let cell = tableView.dequeueReusableCell(withIdentifier: "GifSearchTableViewCell", for: indexPath) as? GifSearchTableViewCell else { return UITableViewCell() }
//
//        cell.gifFavButton.tag = indexPath.row
//        cell.gifFavButton.addTarget(self, action: #selector(didTapAtAddButton(_:)), for: .touchUpInside)
//                   if let imageURL = gifModel?["data"][indexPath.row]["images"]["downsized"]["url"].rawString()
//                   {
//                       cell.setCellData(_data: imageURL)
//                   // if let selectedimageURL =  selectedGifModel?["data"][indexPath.row]["images"]["downsized"]["url"].rawString()
////                    {
//                    if favList?.count  ?? 0 > 0 {
//                        if let favData = favList {
//                            for url in selectedURL {
//                            for f in favData {
//                                if f.gifUrl == url {
//                                    cell.gifFavButton.setTitle("Remove", for: .normal)
//                                }else{
//                                    cell.gifFavButton.setTitle("Add", for: .normal)
//                                }
//                            }
//                            }
//
//                        }
//
//                    }else{
//                        cell.gifFavButton.setTitle("Add", for: .normal)
//                    }
//                   }
//
//
//        return cell
//    }
//
//
//    @objc func didTapAtAddButton(_ sender: UIButton){
//
//        if gifModel?.count ?? 0 > 0 {
//        if let imageURL = gifModel?["data"][sender.tag]["images"]["downsized"]["url"].rawString()
//        {
//
//           // var found: Int = 999
//            self.selectedURL.append(imageURL)
//            //if let selectedimageURL = selectedGifModel?["data"][sender.tag]["images"]["downsized"]["url"].rawString()
//            //{
//            //wait
//            if selectedURL.count > 0 {
//               for i in (0...selectedURL.count - 1) {
//
//                if selectedURL[i] == imageURL {
//                    found = i
//                    break
//                 }
//                }
//            }
//
//            var value = ""
//            for find in selectedURL {
//                value = find
//            }
//
//            if favList?.count ?? 0 > 0 {
//                    if let favData = favList {
//                        for f in favData {
//                            for url in selectedURL {
//
//                            if f.isFav && f.gifUrl == url{
//                                //we need two array and then filter value accordingly then save core data , for example we arely do that erleri
//                           // let arr = selectedTaggedUser.filter({$0._id == studentDataList[indexPath.row]._id}) using this wayok
//                                database.delete(object:(favList?.remove(at: sender.tag))!)
//                                f.isFav = false
//                                database.save()
//                                guard let favMovies = database.add(GifData.self) else {
//                                    return
//                                    }
//
//                                               favMovies.gifUrl = imageURL
//                                               favMovies.isFav = true
//                                               favList?.append(favMovies)
//                                               database.save()
//                                print(favList?.first?.isFav)
//                            } else{
//                                print("its not fav")
//                                guard let favMovies = database.add(GifData.self) else {
//                                    return
//                                    }
//
//                                               favMovies.gifUrl = imageURL
//                                               favMovies.isFav = true
//                                               favList?.append(favMovies)
//                                               database.save()
//                                print(favList?.first?.isFav)
//                            }
//                        }
//                }
//                    }
//                    }
//        else{
//
//            guard let favMovies = database.add(GifData.self) else {
//                return
//                }
//
//                           favMovies.gifUrl = imageURL ///ah kive krna c
//                           favMovies.isFav = true
//                           favList?.append(favMovies)
//                           database.save()
//            print("its not fav")
//            print(favList?.first?.isFav)
//        }
//            self.searchTableView.reloadData()
//
//
//                else{
//                    guard let favMovies = database.add(GifData.self) else {
//                        return
//                        }
//
//                                   favMovies.gifUrl = imageURL
//                                   favMovies.isFav = true
//                                   favList?.append(favMovies)
//                                   database.save()
//                   print(favList?.first?.isFav)
//                }
//
//
//               // self.searchTableView.reloadData()
//
///
//        //}
//        }
//
//
//        }}

//    }












//func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
//    if let cell = tableView.dequeueReusableCell(withIdentifier: "GifSearchTableViewCell", for: indexPath) as? GifSearchTableViewCell
//    {
//
//        cell.setupCell()
////            if giphyArray.count > 0 {
////            cell.setCellData(_data: giphyArray[indexPath.row].giphyUrl)
////            cell.gifFavButton.isSelected = giphyArray[indexPath.row].fav
//        if cell.gifFavButton.isSelected == false{
//            cell.gifFavButton.setImage(UIImage(systemName: "suit.heart"), for: .normal)
//        }else {
//            cell.gifFavButton.setImage(UIImage(systemName: "heart.fill"), for: .normal)
//        }
////            if cell.isSelected
////            }
////            else {
//        if let imageURL = gifModel?["data"][indexPath.row]["images"]["downsized"]["url"].rawString()
//        {
//            cell.setCellData(_data: imageURL)
////                updateArrfromCoreData()
////                let newitem = GiphyDataModel()
////                newitem.giphyUrl = imageURL
////                newitem.fav = false
////                giphyArray.append(newitem)
////            }
//        }
//        cell.favButtonAction = {[unowned self] in
//
//            if (cell.gifFavButton.isSelected){
//                cell.gifFavButton.isSelected = false
//                cell.gifFavButton.setImage(UIImage(systemName: "suit.heart"), for: .normal)
//                if let imageURL = gifModel?["data"][indexPath.row]["images"]["downsized"]["url"].rawString()
//                {
//                    if let favData = favList {
//                        for f in favData {
//                            if f.isFav && f.gifUrl == imageURL{
//                                database.delete(object:(favList?.remove(at: indexPath.row))!)
//                                f.isFav = false
//                                database.save()
//                            }else{
//                                print("its not fav")
//                            }
//                        }
//                    }
//                }
//
//            }
//
//            else {
//                cell.gifFavButton.isSelected = true
//                cell.gifFavButton.setImage(UIImage(systemName: "heart.fill"), for: .normal)
//
//                    if let imageURL = gifModel?["data"][indexPath.row]["images"]["downsized"]["url"].rawString()
//                    {
//                            guard let favMovies = database.add(GifData.self) else {
//                                return
//                            }
//                            favMovies.gifUrl = imageURL
//                            favMovies.isFav = true
//                            favList?.append(favMovies)
//                            database.save()
////                            }
//                        print(favList?.first?.isFav)
//
//                    }
//
//
//            }
//        }
//        return cell
//
//    }
//    else  { return UITableViewCell() }
//
//}
////}
