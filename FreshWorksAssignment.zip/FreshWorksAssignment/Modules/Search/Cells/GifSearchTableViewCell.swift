//
//  GifSearchTableViewCell.swift
//  FreshWorksAssignment
//
//  Created by Happy on 2021-08-07.
//

import UIKit
import SDWebImage
import SwiftyGif

class GifSearchTableViewCell: UITableViewCell {

    @IBOutlet weak var containerView: UIView!
    @IBOutlet weak var gifImageView: UIImageView!
    @IBOutlet weak var gifFavButton: UIButton!
    var myFav = 0
    var urlArr = [String]()
    var favButtonAction : (() -> ())?

    override func awakeFromNib() {
        super.awakeFromNib()
       
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    func setupCell() {
        containerView.layer.cornerRadius = 20
        gifImageView.layer.cornerRadius = 20
        containerView.layer.borderWidth = 2
        containerView.layer.borderColor = UIColor(red: 0, green: 0, blue: 0, alpha: 1).cgColor
        if gifFavButton.isSelected == false{
            gifFavButton.setImage(UIImage(systemName: "suit.heart"), for: .normal)
        }else {
            gifFavButton.setImage(UIImage(systemName: "heart.fill"), for: .normal)
        }
//        gifFavButton.isSelected = false
        gifFavButton.setImage(UIImage(systemName: "heart"), for: .normal)
        let buttonSelect = UITapGestureRecognizer(target: self, action: #selector(buttonTapped))
        gifFavButton.isUserInteractionEnabled = true
        gifFavButton.addGestureRecognizer(buttonSelect)
    }
    func setCellData(_data: String){
        let url = URL(string: _data)
        let loader = UIActivityIndicatorView(style: .medium)
        guard let img = url else { return  }
        DispatchQueue.main.async {
            self.gifImageView.setGifFromURL(img, customLoader: loader)
        }
    }
    @objc func buttonTapped() {
        favButtonAction?()

    }
    
}
