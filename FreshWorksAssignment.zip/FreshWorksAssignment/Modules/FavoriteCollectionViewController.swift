//
//  FavoriteCollectionViewController.swift
//  FreshWorksAssignment
//
//  Created by Happy on 2021-08-07.
//

import UIKit
import CoreData
import SwiftyGif

private let reuseIdentifier = "Cell"

class FavoriteCollectionViewController: UIViewController, UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout {
    @IBOutlet weak var favouriteCollectionView: UICollectionView!
    var favList : [GifData]? = []
    let database = DatabaseHandler()
    override func viewDidLoad() {
        super.viewDidLoad()
        setupCollectionView()
    }
    func fetchGifsData() {
        favList = database.fetch(GifData.self)
        favouriteCollectionView.reloadData()
        print(favList?.count)
    }
    func setupCollectionView() {
        favouriteCollectionView.delegate = self
        favouriteCollectionView.dataSource = self
    }
    override class func description() -> String {
        "FavViewController"
    }
    override func viewWillAppear(_ animated: Bool) {
        fetchGifsData()
    }
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
            return favList?.count ?? 0
        }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
           let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath as IndexPath) as! GifFavoriteCollectionViewCell
        cell.setupCell()
        if favList?.count ?? 0 > 0 {
            cell.setCellData(_data: favList![indexPath.item].gifUrl)
            
        }
        
        cell.gifFavouriteButton.tag = indexPath.row
        cell.unfavButtonAction = {[unowned self] in
            if cell.gifFavouriteButton.isSelected == true {
                cell.gifFavouriteButton.isSelected = false
                cell.gifFavouriteButton.setImage(UIImage(systemName: "heart.fill"), for: .normal)
            }else {
                cell.gifFavouriteButton.isSelected = true
                cell.gifFavouriteButton.setImage(UIImage(systemName: "suit.heart"), for: .normal)
            }
        }
            
           return cell
       }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        let itemSize = (collectionView.frame.height - (collectionView.contentInset.left + collectionView.contentInset.right)) / 3
        let itemSize1 = (collectionView.frame.width - (collectionView.contentInset.left + collectionView.contentInset.right)) / 2.2
                  return CGSize(width: itemSize1, height: itemSize)
            
}
   
}
//extension FavoriteCollectionViewController:UICollectionViewDataSource,UICollectionViewDelegateFlowLayout,UICollectionViewDelegate {
//
//
//}
