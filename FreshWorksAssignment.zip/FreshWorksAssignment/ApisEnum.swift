//
//  ApisEnum.swift
//  FreshWorksAssignment
//
//  Created by Happy on 2021-08-09.
//
import UIKit

class SaveButton: UIButton {

  // Images
  let buttonChecked = UIImage(named: "save_icon_greenCheck")
  let buttonUnChecked = UIImage(named: "save_icon_white")


  //Bool Property
    override var isSelected: Bool{
    didSet{
        if isSelected {
            self.setImage(buttonChecked, for: UIControl.State.selected)
      }else{
        self.setImage(buttonUnChecked, for: UIControl.State.normal)
      }
        UserDefaults.standard.set(isSelected, forKey: "isBtnChecked")
     // NSUserDefaults.standardUserDefaults().synchronize()
    }
  }

  override init(frame: CGRect){
    super.init(frame:frame)
    self.layer.masksToBounds = true
    self.setImage(buttonUnChecked, for: UIControl.State.normal)

    self.addTarget(self, action: "buttonClicked:", for: UIControl.Event.touchUpInside)
  }

  required init(coder aDecoder: NSCoder) {
    super.init(coder: aDecoder)!
  }

  func buttonClicked(sender: UIButton) {
    self.isSelected = !self.isSelected
  }
}
