//
//  ViewController.swift
//  FreshWorksAssignment
//
//  Created by Happy on 2021-08-06.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

//    if let imageData = self.gifModel?[indexPath.row]
   //                               {
   //                                   if let images = imageData["images"] as? [String:AnyObject]
   //                                   {
   //                                       if let downSize = images["downsized"] as? [String:AnyObject]
   //                                       {
   //                                        //   self.gifStringArr = downSize["url"] as! [String]

}

