//
//  SearchTableViewController + SearchBarMethods.swift
//  FreshWorksAssignment
//
//  Created by Happy on 2021-08-12.
//

import Foundation
import UIKit
extension SearchTableViewController : UISearchControllerDelegate,UISearchResultsUpdating  {
    // MARK:- set up search bar
   
    func setupSearchBar() {
        searchController.searchResultsUpdater = self
        searchController.hidesNavigationBarDuringPresentation = false
        searchController.dimsBackgroundDuringPresentation = false
        searchController.searchBar.sizeToFit()
        self.searchTableView.tableHeaderView = searchController.searchBar
    }
    // MARK:- update function
    
    func updateSearchResults(for searchController: UISearchController) {
        timer.invalidate()
        guard let text = searchController.searchBar.text else { return }
        searchGifText = text
        timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(searchGiphyAPI), userInfo: nil, repeats: false)
    }
    // MARK:- call api to get giphy data from the sever about search text    
    @objc func searchGiphyAPI()
    {
        if(searchGifText == "")
        {
            self.getGifDataFromServer()
        }
        else{
            searchActivityIndicator.startAnimating()
            let parm = [URLQueryItem(name: "q", value: searchGifText), URLQueryItem(name: "api_key", value: "Qvz4B1vkcNUr8V68lMgs5eX8HR7v2Hx1")]
            api.getApiData(requestUrl: gifSearchingUrl.absoluteString, parameters: parm) { res  in
                DispatchQueue.main.async {
                    self.searchActivityIndicator.stopAnimating()
                }
                self.gifModel = res
                DispatchQueue.main.async {
                    self.searchTableView.reloadData()
                }
            }
            
        }
    }
}
