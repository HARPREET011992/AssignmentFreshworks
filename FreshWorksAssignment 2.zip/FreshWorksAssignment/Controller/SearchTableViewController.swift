//
//  SearchTableViewController.swift
//  FreshWorksAssignment
//
//  Created by Happy on 2021-08-07.
//

import UIKit
import SwiftyGif
import SwiftyJSON
class SearchTableViewController: UIViewController {
    // MARK:- outlets for the viewController
    @IBOutlet var searchTableView: UITableView!
    let api = NetworkManager()
    var database = DatabaseHandler()
    let searchController = UISearchController(searchResultsController: nil)
    var searchActivityIndicator = UIActivityIndicatorView(style: UIActivityIndicatorView.Style.gray)
    var gifModel: JSON?
    var offsetCount = 0
    var totalCount = 0
    var isLoadingGifs = false
    var selectedURL = [String]()
    var favList : [GifData]? = []
    var selectedGifModel : JSON?
    var timer = Timer.init()
    var searchGifText = ""
    var index =  0
    var gifTrendingUrl: URL {
         return URL(string: "http://api.giphy.com/v1/gifs/trending")!
    }
    var gifSearchingUrl: URL {
         return URL(string: "http://api.giphy.com/v1/gifs/search")!
    }
   //temp
    var isNewDataLoading = false
    var displayGifs = [String]()
    var limit = 50
    var models = [JSON]()
    var totalResult = 0
    var totalUser = [Int]()
    // MARK:- lifeCycle for the viewController
    override func viewDidLoad() {
        super.viewDidLoad()
        updateTableContent()
        setupTableView()
        setupSearchBar()
        showActivityIndicatory()
        clearCoreData()
    }
    // MARK:- variables for the SearchviewController
    override class func description() -> String {
        "SearchViewController"
    }
    override func viewWillAppear(_ animated: Bool) {
        favList = database.fetch(GifData.self)
        searchTableView.reloadData()
    }
    // MARK:- function to show activity indicator while searching for gifs
   
    func showActivityIndicatory() {
        searchActivityIndicator = UIActivityIndicatorView(style: UIActivityIndicatorView.Style.large)
        searchActivityIndicator.center = self.view.center
        self.view.addSubview(searchActivityIndicator)
    }
    func updateTableContent() {
        getGifDataFromServer()
    }
    // MARK:- function to clear previous favourite gifs from local storage    
    func clearCoreData() {
        database.clearData(GifData.self)
    }
    // MARK:- function to get trending gifs from the server
    func getGifDataFromServer(){
        let parm = [URLQueryItem(name: "api_key", value: "Qvz4B1vkcNUr8V68lMgs5eX8HR7v2Hx1"),URLQueryItem(name: "offset", value:String(offsetCount))]
        api.getApiData(requestUrl:  gifTrendingUrl.absoluteString, parameters: parm) { [self] response   in
            self.gifModel = response
            self.totalResult = self.gifModel?["pagination"]["total_count"].intValue ?? 0
            DispatchQueue.main.async {
                self.searchTableView.reloadData()
            }
        }
    }
}

