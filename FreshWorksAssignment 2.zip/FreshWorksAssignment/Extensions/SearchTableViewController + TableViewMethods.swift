//
//  SearchTableViewController + TableViewMethods.swift
//  FreshWorksAssignment
//
//  Created by Happy on 2021-08-12.
//

import Foundation
import UIKit
extension SearchTableViewController : UITableViewDelegate,UITableViewDataSource, UIScrollViewDelegate {
    func setupTableView() {
        searchTableView.delegate = self
        searchTableView.dataSource = self
    }

    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
//        if indexPath.row ==  gifModel?["data"].count ?? 0 - 1 {
//            index = gifModel?["data"].count ?? 0 - 1
//            if index + 50 > models.count - 1{
//                limit = models.count - index
//            }else{
//                limit = index + 20
//            }
//            while index < limit {
//                index = index + 1
//            }
//            self.isNewDataLoading = true
//            self.loadMoreItemsForList()
//        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
       return 300
   }
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            return gifModel?["data"].count ?? 0
   }
   
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if let cell = tableView.dequeueReusableCell(withIdentifier: "GifSearchTableViewCell", for: indexPath) as? GifSearchTableViewCell
        {
            
            cell.setupCell()
            if let imageURL = gifModel?["data"][indexPath.row]["images"]["downsized"]["url"].rawString()
            {
                cell.setCellData(_data: imageURL)
                let arr = favList?.filter({$0.gifUrl == imageURL})
                if arr?.count ?? 0 > 0 {
                    cell.gifFavButton.isSelected = true
                    cell.gifFavButton.setImage(UIImage(systemName: "heart.fill"), for: .normal)
                }
                else{
                    cell.gifFavButton.isSelected = false
                    cell.gifFavButton.setImage(UIImage(systemName: "suit.heart"), for: .normal)
                    
                }
            }
            cell.favButtonAction = {[unowned self] in
                buttonTapped(cell.gifFavButton,indexPath.row)
            }
            return cell
            
        }
        else  { return UITableViewCell() }
        
    }
    // MARK:- Method to append and delete favourite gifs into local database

    func buttonTapped( _ sender:UIButton,_ i :Int){
        if (sender.isSelected){
            sender.isSelected = false
            sender.setImage(UIImage(systemName: "suit.heart"), for: .normal)
            if let imageURL = gifModel?["data"][i]["images"]["downsized"]["url"].rawString()
            {
                if let favData = favList {
                    for i in 0..<favData.count {
                        if favData[i].isFav && favData[i].gifUrl == imageURL{
                            favData[i].isFav = false
                            database.delete(object: (favList?[i])!)
                            database.save()
                        }
                    }
                }
            }
            
        }
        
        else {
            sender.isSelected = true
            sender.setImage(UIImage(systemName: "heart.fill"), for: .normal)
            
            if let imageURL = gifModel?["data"][i]["images"]["downsized"]["url"].rawString()
            {
                guard let favMovies = database.add(GifData.self) else {
                    return
                }
                favMovies.gifUrl = imageURL
                favMovies.isFav = true
                favList?.append(favMovies)
                database.save()
            }
            
            
        }
    }
}
